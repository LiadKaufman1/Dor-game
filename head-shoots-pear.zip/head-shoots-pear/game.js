// Canvas setup
const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');
const W = canvas.width, H = canvas.height;

// HUD
const scoreEl = document.getElementById('score');
const livesEl = document.getElementById('lives');
const restartBtn = document.getElementById('restart');

// Images
const headImg = new Image();
headImg.src = "Dor.PNG";          // ראש בתחתית
const pearImg = new Image();
pearImg.src = "אגס.PNG";           // קליע
const fanImg = new Image();
fanImg.src = "מאוורר.jpg";        // אויב

let assetsReady = {head:false, pear:false, fan:false};
headImg.onload = ()=> assetsReady.head = true;
pearImg.onload = ()=> assetsReady.pear = true;
fanImg.onload  = ()=> assetsReady.fan  = true;

// Game state
let player, bullets, enemies, score, lives, running, lastShot, keys, spawnTimer, spin;

// Init/reset
function reset(){
  player = { x: W/2, y: H-80, w: 100, h: 100, speed: 6 };
  bullets = [];
  enemies = [];
  score = 0;
  lives = 3;
  running = true;
  lastShot = 0;
  spawnTimer = 0;
  spin = 0;
  keys = {left:false, right:false, shooting:false};
  updateHUD();
}
function updateHUD(){
  scoreEl.textContent = `נקודות: ${score}`;
  livesEl.textContent = `חיים: ${lives}`;
}
restartBtn.addEventListener('click', reset);

// Input
document.addEventListener('keydown', e=>{
  if (e.key === 'ArrowLeft' || e.key.toLowerCase()==='a') keys.left = true;
  if (e.key === 'ArrowRight' || e.key.toLowerCase()==='d') keys.right = true;
  if (e.key === ' '){ e.preventDefault(); keys.shooting = true; }
});
document.addEventListener('keyup', e=>{
  if (e.key === 'ArrowLeft' || e.key.toLowerCase()==='a') keys.left = false;
  if (e.key === 'ArrowRight' || e.key.toLowerCase()==='d') keys.right = false;
  if (e.key === ' ') keys.shooting = false;
});
canvas.addEventListener('mousemove', e=>{
  const rect = canvas.getBoundingClientRect();
  const mx = (e.clientX - rect.left) * (canvas.width / rect.width);
  player.x = Math.max(player.w/2, Math.min(W - player.w/2, mx));
});
canvas.addEventListener('mousedown', ()=> keys.shooting = true);
canvas.addEventListener('mouseup', ()=> keys.shooting = false);

// Helpers
function rectsIntersect(a,b){
  return !(a.x + a.w < b.x || a.x > b.x + b.w || a.y + a.h < b.y || a.y > b.y + b.h);
}

// Spawn enemies (fans) from top
function spawnEnemy(dt){
  spawnTimer += dt;
  if (spawnTimer >= 0.75){ // כל 0.75 שנ׳
    spawnTimer = 0;
    const size = 90 + Math.random()*40; // 90-130px
    const x = Math.random() * (W - size);
    const vy = 1.6 + Math.random()*1.6; // מהירות מטה
    enemies.push({x, y: -size, w:size, h:size, vy});
  }
}

// Shoot pears upward from the head's forehead
function shoot(ts){
  if (!keys.shooting) return;
  if (ts - lastShot < 220) return; // cadence
  lastShot = ts;
  const bw = 36, bh = 36;
  bullets.push({
    x: player.x - bw/2, 
    y: player.y + 10,   // יוצא מהראש
    w: bw, h: bh, vy: -7.2
  });
}

// Update
let prev = performance.now();
function loop(ts){
  const dt = (ts - prev)/1000; prev = ts;
  if (running){
    // player move
    if (keys.left)  player.x -= player.speed;
    if (keys.right) player.x += player.speed;
    player.x = Math.max(player.w/2, Math.min(W - player.w/2, player.x));

    // shooting
    shoot(ts);

    // bullets
    bullets.forEach(b => b.y += b.vy);
    bullets = bullets.filter(b => b.y + b.h > -10);

    // enemies
    spawnEnemy(dt);
    enemies.forEach(e => e.y += e.vy);
    enemies = enemies.filter(e => e.y < H + 40);

    // collisions: bullet vs enemy
    for (let i=enemies.length-1; i>=0; i--){
      const e = enemies[i];
      let hit = false;
      for (let j=bullets.length-1; j>=0; j--){
        const b = bullets[j];
        if (rectsIntersect({x:b.x,y:b.y,w:b.w,h:b.h}, {x:e.x,y:e.y,w:e.w,h:e.h})){
          bullets.splice(j,1);
          hit = true; break;
        }
      }
      if (hit){
        enemies.splice(i,1);
        score += 10;
        updateHUD();
      }
    }

    // collisions: enemy vs player (head)
    for (const e of enemies){
      if (rectsIntersect({x:player.x-player.w/2,y:player.y-player.h/2,w:player.w,h:player.h}, e)){
        lives -= 1;
        updateHUD();
        // דחוף את האויב למטה כדי לא לספור פעמיים
        e.y = H + 100;
        if (lives <= 0) running = false;
      }
    }
  }

  draw();
  requestAnimationFrame(loop);
}

// Draw
function draw(){
  // bg
  ctx.fillStyle = '#000';
  ctx.fillRect(0,0,W,H);

  // player head
  if (assetsReady.head){
    ctx.drawImage(headImg, player.x - player.w/2, player.y - player.h/2, player.w, player.h);
  }else{
    ctx.fillStyle = '#888'; ctx.fillRect(player.x-25, player.y-25, 50, 50);
  }

  // bullets (pears)
  for (const b of bullets){
    if (assetsReady.pear){
      ctx.drawImage(pearImg, b.x, b.y, b.w, b.h);
    }else{
      ctx.fillStyle = '#7aff00'; ctx.fillRect(b.x, b.y, b.w, b.h);
    }
  }

  // enemies (fans) with rotation
  spin += 0.08;
  for (const e of enemies){
    if (assetsReady.fan){
      ctx.save();
      ctx.translate(e.x + e.w/2, e.y + e.h/2);
      ctx.rotate(spin);
      ctx.drawImage(fanImg, -e.w/2, -e.h/2, e.w, e.h);
      ctx.restore();
    }else{
      ctx.fillStyle = '#19c37d'; ctx.fillRect(e.x, e.y, e.w, e.h);
    }
  }

  if (!running){
    ctx.fillStyle = 'rgba(0,0,0,0.6)';
    ctx.fillRect(0,0,W,H);
    ctx.fillStyle = '#fff';
    ctx.font = '28px system-ui';
    const msg = `נגמר! ניקוד: ${score} — לחץ "התחל מחדש"`;
    const tw = ctx.measureText(msg).width;
    ctx.fillText(msg, (W-tw)/2, H/2);
  }
}

// Kickoff
reset();
requestAnimationFrame(loop);
